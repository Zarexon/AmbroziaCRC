
const deleteUser = (data) => {
  const currentUser2 = document.querySelector('#stergereUser').value;
  data.forEach(doc => {
    var docum = doc.id;
    if (currentUser2.localeCompare(doc.data().eMail) == 0) {
      db.collection('users').doc(docum).delete();
      // admin.auth().deleteUser(docum).then(() => {
      //     console.log('Successfully deleted user');
      //   })
      //   .catch((error) => {
      //     console.log('Error deleting user:', error);
      //   });
    }
    else {
      console.log("Userul nu e sters!");
    }
  });
}


