var admin = require("firebase-admin");

var serviceAccount = require("C:/Users/Robert/Desktop/DATC_CRC/serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: "https://my-project-c0392-default-rtdb.firebaseio.com"
});
