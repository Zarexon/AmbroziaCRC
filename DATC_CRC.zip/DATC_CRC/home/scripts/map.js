/**
    * Firebase config block.
    */
var config = {
    apiKey: "AIzaSyBSEVcuxkmmMIPtFMbIUJ2KyJzky2f6EOY",
    authDomain: "my-project-c0392.firebaseapp.com",
    databaseURL: "https://my-project-c0392-default-rtdb.firebaseio.com",
    projectId: "my-project-c0392",
    storageBucket: "my-project-c0392.appspot.com",
    messagingSenderId: "968137679410",
    appId: "1:968137679410:web:51495187ff5b7a017b122b",
    measurementId: "G-9LFQH3YE12"
};
firebase.initializeApp(config);

// make auth and firestore references
const auth = firebase.auth();
const db = firebase.firestore();

// update firestore settings
db.settings({ timestampsInSnapshots: true });
/**
 * Data object to be written to Firebase.
 */
var data = { senderUid: null, lat: null, lng: null };

/**
* Starting point for running the program. Authenticates the user.
* @param {function()} onAuthSuccess - Called when authentication succeeds.
*/
function initAuthentication(onAuthSuccess) {
    firebase.auth().signInAnonymously().catch(function (error) {
        console.log(error.code + ', ' + error.message);
    }, { remember: 'sessionOnly' });

    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            data.senderUid = user.uid;
            onAuthSuccess();
        } else {
            // User is signed out.
        }
    });
}

    var database = firebase.database();
    const rootRef = database.ref('clicks');
let map, infoWindow;
/**
 * Creates a map object with a click listener and a heatmap.
 */
function initMap() {
    const map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 45.760696, lng: 21.226788 },
        zoom: 14,
        mapTypeId: "roadmap",
        disableDoubleClickZoom: true,
        streetViewControl: false,
    });


    // Listen for clicks and add the location of the click to firebase.
    map.addListener('click', function (e) {
        data.lat = e.latLng.lat();
        data.lng = e.latLng.lng();
        addToFirebase(data);
    });

    // Create a heatmap.
    var heatmap = new google.maps.visualization.HeatmapLayer({
        data: [],
        map: map,
        radius: 14
    });

    rootRef.on('value', function (snapshot) {
        snapshot.forEach(function (childSnapshot) {

            var childData = childSnapshot.val();
            var lat = childData.lat;
            var long = childData.lng;

            const punct = { lat: lat, lng: long };
            const marker = new google.maps.Marker({ position: punct, map });
            marker.addListener("click", function() {
                if (confirm("Delete map marker from database?")) {
                    rootRef.child(childSnapshot.key).remove();
                    window.location.reload();
                    marker.setMap(null);
                    window.alert("Marker deleted!");
                  } else {
                    window.alert("You canceled!");
                  }
            });    
        });
    })
    initAuthentication(initFirebase.bind(undefined, heatmap));

}

/**
 * Set up a Firebase with deletion on clicks older than expiryMs
 * @param {!google.maps.visualization.HeatmapLayer} heatmap The heatmap to
 */
function initFirebase(heatmap) {

    // Reference to the clicks in Firebase.
    var clicks = firebase.database().ref('clicks');


    // Listen for clicks and add them to the heatmap.
    clicks.orderByChild('timestamp').on('child_added',
        function (snapshot) {
            // Get that click from firebase.
            var newPosition = snapshot.val();
            var point = new google.maps.LatLng(newPosition.lat, newPosition.lng);

            // Add the point to the heatmap.
            heatmap.getData().push(point);
            
        }
    );

    // Remove old data from the heatmap when a point is removed from firebase.
    clicks.on('child_removed', function (snapshot, prevChildKey) {
        var heatmapData = heatmap.getData();
        var i = 0;
        while (snapshot.val().lat != heatmapData.getAt(i).lat()
            || snapshot.val().lng != heatmapData.getAt(i).lng()) {
            i++;
        }
        heatmapData.removeAt(i);
    });
}

/**
 * Updates the last_message/ path with the current timestamp.
 * @param {function(Date)} addClick After the last message timestamp has been updated,
 *     this function is called with the current timestamp to add the
 *     click to the firebase.
 */
function getTimestamp(addClick) {
    // Reference to location for saving the last click time.
    var ref = firebase.database().ref('last_message/' + data.sender);

    // Set value to timestamp.
    ref.set(firebase.database.ServerValue.TIMESTAMP, function (err) {
        if (err) {  // Write to last message was unsuccessful.
            console.log(err);
        } else {  // Write to last message was successful.
            ref.once('value', function (snap) {
                addClick(snap.val());  // Add click with same timestamp.
            }, function (err) {
                console.warn(err);
            });
        }
    });
}

/**
 * Adds a click to firebase.
 * @param {Object} data The data to be added to firebase.
 *     It contains the lat, lng, sender and timestamp.
 */
function addToFirebase(data) {
    getTimestamp(function () {
        // Add the new timestamp to the record data.
        var ref = firebase.database().ref('clicks').push(data, function (err) {
            if (err) {  // Data was not written to firebase.
                console.warn(err);
            }
        });
    });
}