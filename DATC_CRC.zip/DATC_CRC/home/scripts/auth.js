
// listen for auth status changes
auth.onAuthStateChanged(user => {
  if (user) {
    console.log('user logged in: ', user);
    db.collection('users').onSnapshot(snapshot => {
      console.log(snapshot.docs);
      setupUsers(snapshot.docs);
      currentUser(user);
    });
  } else {
    console.log('user logged out');
    setupUsers([]);
    currentUser();
  }
})

function stergereUtil() {

  db.collection('users').onSnapshot(snapshot => {
    deleteUser(snapshot.docs);
  });
}
// function stergereUtil(){
//   db.collection('users').onSnapshot(snapshot => {
//     deleteUser(snapshot.docs);
//     console.log(snapshot.docs);
//   });
// }

// login
const loginForm = document.querySelector('#login-form');
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // get user info
  const email = loginForm['login-email'].value;
  const password = loginForm['login-password'].value;

  // log the user in
  // if (doc.data().BasicUser != true) {
    auth.signInWithEmailAndPassword(email, password).then((cred) => {
      console.log(cred.user);
      // close the signup modal & reset form
      const modal = document.querySelector('#modal-login');
      M.Modal.getInstance(modal).close();
      loginForm.reset();
      window.location.assign("index.html");
    });
  // }
});


